
package reto3.reto3;

import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author juanp
 */
public interface InterfaceMensaje extends CrudRepository<Mensaje, Integer>{
    
}
