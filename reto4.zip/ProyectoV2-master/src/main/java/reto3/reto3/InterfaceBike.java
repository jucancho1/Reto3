
package reto3.reto3;

import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author juanp
 */
public interface InterfaceBike extends CrudRepository<Bike, Integer>{
    
    
}
